// number example
let jsVersion = 6;
console.log(`JS Version is : ${jsVersion}`);

// String Examples
let empName = 'John';
console.log(`Emp Name is : ${empName}`);

// boolean Examples
let isJSEasy = true;
console.log(`Is JS Easy ? ${isJSEasy}`);

// reassignment example of variables
let abc;
abc = 10;
abc = 'john';
abc = true;
abc = null;
console.log(`value : ${abc} type : ${typeof abc}`);

// constant values
const MONTH = 'JANUARY';
console.log(MONTH);
