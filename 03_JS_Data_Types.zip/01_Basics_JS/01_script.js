//Alert Box
//alert("Good Morning");

// confirm Box
//confirm("Hello JS");

//console log
console.log("Welcome to JavaScript");

//Display date on the console
console.log(new Date());
console.log(new Date().toLocaleDateString());
console.log(new Date().toLocaleTimeString());
